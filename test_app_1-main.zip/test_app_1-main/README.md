# Demostración creación de aplicación con Python:



Acceso a la aplicación: https://econdavidzh-test-app-1-test-app-1-yd4jn7.streamlit.app/
